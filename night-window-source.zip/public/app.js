const $=selector=>document.querySelector(selector);
const icons={
 doorway:'<path d="M5 21V3h14v18M3 21h18"/><path d="M8 21V7l8-2v16"/><circle cx="13" cy="13" r=".7"/>',
 globe:'<circle cx="12" cy="12" r="9"/><ellipse cx="12" cy="12" rx="4" ry="9"/><path d="M3 12h18"/>',
 search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
 arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',chevron:'<path d="m9 6 6 6-6 6"/>',
 back:'<path d="m12 5-7 7 7 7M5 12h15"/>',forward:'<path d="m12 5 7 7-7 7M19 12H4"/>',
 reload:'<path d="M20 7v5h-5M4 17v-5h5M5.4 8a7.5 7.5 0 0 1 12-3L20 8M4 16l2.6 3A7.5 7.5 0 0 0 19 16"/>',
 home:'<path d="m3 11 9-8 9 8M5 10v11h5v-7h4v7h5V10"/>',
 bookmark:'<path d="M6 4h12v17l-6-4-6 4z"/>',
 settings:'<path d="m9 3-.7 3-2.8 1L3 6l-2 3 2.2 2v2L1 15l2 3 2.5-1 2.8 1 .7 3h6l.7-3 2.8-1 2.5 1 2-3-2.2-2v-2L23 9l-2-3-2.5 1-2.8-1L15 3z" transform="translate(1 1) scale(.9)"/><circle cx="12" cy="12" r="3"/>',
 history:'<path d="M3 4v5h5M3.5 8a9 9 0 1 1-.3 8M12 7v5l3 2"/>',note:'<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 8h8M8 12h8M8 16h5"/>',
 grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
 desktop:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',
 palette:'<path d="M12 3a9 9 0 1 0 0 18h1a2 2 0 0 0 1-4c-2-1-1-3 1-3h3a3 3 0 0 0 3-3 9 9 0 0 0-9-8Z"/><circle cx="7" cy="10" r=".7"/><circle cx="11" cy="7" r=".7"/><circle cx="16" cy="8" r=".7"/>',
 expand:'<path d="M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5"/>',minus:'<path d="M5 12h14"/>',square:'<rect x="5" y="5" width="14" height="14" rx="2"/>',close:'<path d="m6 6 12 12M6 18 18 6"/>',plus:'<path d="M12 4v16M4 12h16"/>',zap:'<path d="m14 2-10 12h7l-1 8 10-12h-7z"/>',check:'<path d="m5 12 4 4L19 6"/>',trash:'<path d="M3 6h18M8 6V3h8v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>'
};
function icon(name){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.globe}</svg>`;}
function paintIcons(root=document){root.querySelectorAll('[data-icon]').forEach(el=>{el.innerHTML=icon(el.dataset.icon);});}
const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function read(key,fallback){try{return JSON.parse(localStorage.getItem('nw:'+key))??fallback;}catch{return fallback;}}
function save(key,value){try{localStorage.setItem('nw:'+key,JSON.stringify(value));return true;}catch{toast('Your browser could not save this change. Storage may be full or disabled.');return false;}}
const defaults=[{name:'Wikipedia',url:'https://www.wikipedia.org/'},{name:'YouTube',url:'https://www.youtube.com/'},{name:'Reddit',url:'https://www.reddit.com/'},{name:'GitHub',url:'https://github.com/'},{name:'DuckDuckGo',url:'https://duckduckgo.com/'}];
let customWallpaperUrl=null,customWallpaperType=null;
let enterTimer=0,revealTimer=0,entryInProgress=false;
const closingTimers=new WeakMap();
const motionAllowed=()=>prefs.motion&&!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let prefs={liveWallpaper:true,welcomeWallpaper:'moonlight',loopWallpaper:true,engine:'scramjet',wallpaper:'moonlight',accent:'ice',search:'google',clock24:false,motion:true,...read('settings',{})};
if(!prefs.moonlightThemeVersion){if(prefs.wallpaper==='galaxy')prefs.wallpaper='moonlight';if(prefs.welcomeWallpaper==='galaxy')prefs.welcomeWallpaper='moonlight';if(prefs.accent==='violet')prefs.accent='ice';prefs.moonlightThemeVersion=3;save('settings',prefs);}
if(!['basic','scramjet'].includes(prefs.engine))prefs.engine='scramjet';
let bookmarks=read('bookmarks',defaults),recent=read('history',[]),tabs=[],activeId=null,frontZ=20,toastTimer,controllerPromise,settingsTab='engines',panelName='settings',wallpaperTarget='both';
if(!Array.isArray(bookmarks))bookmarks=defaults;if(!Array.isArray(recent))recent=[];
const engineName=()=>prefs.engine==='scramjet'?'Scramjet':'MOONLIGHT OS Basic';
function toast(message){clearTimeout(toastTimer);$('#toast').textContent=message;$('#toast').hidden=false;toastTimer=setTimeout(()=>$('#toast').hidden=true,4500);}
function applyPrefs(){
 document.documentElement.dataset.wallpaper=prefs.wallpaper;
 document.documentElement.dataset.accent=prefs.accent;
 document.documentElement.dataset.motion=prefs.motion?'on':'off';
 document.documentElement.dataset.liveWallpaper=prefs.liveWallpaper?'on':'off';
 $('#top-engine').textContent=prefs.engine==='scramjet'?'SCRAMJET':'BASIC';
 updateStatus();updateClock();applyWallpapers();updateMotionLabel();
}
function updateMotionLabel(){
 const moving=motionAllowed()&&prefs.liveWallpaper;
 $('.motion-button').setAttribute('aria-pressed',String(prefs.liveWallpaper));
 $('#motion-label').textContent=moving?'Live atmosphere':'Still atmosphere';
}
function updateClock(){
 const d=new Date(),h=d.getHours();
 $('#hours').textContent=String(prefs.clock24?h:h%12||12).padStart(2,'0');
 $('#minutes').textContent=String(d.getMinutes()).padStart(2,'0');
 $('#meridiem').textContent=prefs.clock24?'':h<12?'AM':'PM';
 $('#desktop-day').textContent=h<5?'A little room for the night.':h<12?'Good morning.':h<17?'Good afternoon.':'Good evening.';
 $('#full-date').textContent=d.toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});
 $('#top-date').textContent=d.toLocaleDateString(undefined,{month:'short',day:'numeric'})+' · '+d.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',hour12:!prefs.clock24});
}
function currentTab(){return tabs.find(t=>t.id===activeId);}
function focusWindow(el){document.querySelectorAll('.window').forEach(node=>node.style.zIndex=node===el?'40':'30');}
function showWindow(el){clearTimeout(closingTimers.get(el));el.classList.remove('is-closing');el.hidden=false;el.inert=!$('#welcome-screen').hidden;focusWindow(el);}
function hideWindow(el){clearTimeout(closingTimers.get(el));if(el.hidden)return;el.inert=true;const finish=()=>{el.hidden=true;el.classList.remove('is-closing');};if(!motionAllowed()){finish();return;}el.classList.add('is-closing');closingTimers.set(el,setTimeout(finish,220));}
function showBrowser(){
 if(!tabs.length)newTab();
 document.body.classList.add('browser-app-open');
 const el=$('#browser-window');el.removeAttribute('style');el.classList.remove('maximized');
 showWindow(el);$('#dock-browser').classList.add('active','running');$('#launcher').hidden=true;
 $('#address').focus({preventScroll:true});
}
function hideBrowser(){showDesktop();}
function showDesktop(){
 document.body.classList.remove('browser-app-open');
 for(const el of document.querySelectorAll('.window')){clearTimeout(closingTimers.get(el));el.hidden=true;el.inert=true;el.classList.remove('is-closing');}
 $('#dock-browser').classList.remove('active');$('#launcher').hidden=true;
 $('.desktop-browse').focus({preventScroll:true});
}
function maximizeBrowser(){showBrowser();}
function zoomPage(delta){
 const tab=currentTab();if(!tab)return;
 tab.zoom=delta===0?1:Math.min(2,Math.max(.5,(tab.zoom||1)+delta));applyPageZoom(tab);
}
function applyPageZoom(tab){
 const value=tab.zoom||1;const content=tab.frame||tab.view.querySelector('.new-tab-page');
 if(content){content.style.transformOrigin='0 0';content.style.transform=`scale(${value})`;content.style.width=(100/value)+'%';content.style.height=(100/value)+'%';}
 if(tab.id===activeId)$('#page-zoom-label').textContent=Math.round(value*100)+'%';
}
let doorAudio;
function playDoorSound(){
 try{
  const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;
  doorAudio=doorAudio||new Audio();doorAudio.resume().catch(()=>{});
  const t=doorAudio.currentTime;const gain=doorAudio.createGain();gain.gain.setValueAtTime(0,t);gain.gain.linearRampToValueAtTime(.055,t+.08);gain.gain.exponentialRampToValueAtTime(.001,t+1.7);gain.connect(doorAudio.destination);
  for(const hz of [83,127,191]){const tone=doorAudio.createOscillator();tone.type='triangle';tone.frequency.setValueAtTime(hz,t);tone.frequency.exponentialRampToValueAtTime(hz*.65,t+1.5);tone.connect(gain);tone.start(t);tone.stop(t+1.8);}
  const chime=doorAudio.createOscillator(),g=doorAudio.createGain();chime.frequency.setValueAtTime(660,t+1);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.025,t+1.2);g.gain.exponentialRampToValueAtTime(.001,t+2.8);chime.connect(g);g.connect(doorAudio.destination);chime.start(t+1);chime.stop(t+2.9);
 }catch{}
}

function newTab(){if(tabs.length>=8){toast('You have 8 tabs open. Close one before opening another.');return;}const tab={id:crypto.randomUUID(),url:'',title:'New tab',engine:prefs.engine,view:document.createElement('div'),frame:null,scram:null,entries:[],position:-1,request:null,seq:0,loading:false,timer:null};tab.view.className='tab-view';$('#tab-views').appendChild(tab.view);tabs.push(tab);renderHome(tab);selectTab(tab.id);return tab;}
function cleanup(tab){tab.request?.abort();clearTimeout(tab.timer);tab.seq++;tab.scram=null;tab.frame=null;tab.loading=false;tab.view.replaceChildren();}
function renderHome(tab){cleanup(tab);tab.url='';tab.title='New tab';tab.engine=prefs.engine;tab.entries=[];tab.position=-1;const content=$('#new-tab-template').content.cloneNode(true);content.querySelector('.new-tab-hint').textContent=prefs.engine==='scramjet'?'Scramjet powers your browsing. MOONLIGHT OS makes it yours.':'Basic opens simple pages with website scripts and forms turned off.';const form=content.querySelector('form');form.addEventListener('submit',e=>{e.preventDefault();navigate(form.querySelector('input').value,tab);});tab.view.appendChild(content);applyPageZoom(tab);renderQuickLinks(tab);paintIcons(tab.view);renderTabs();updateStatus();}
function renderQuickLinks(tab){const links=tab.view.querySelector('.quick-links');if(!links)return;links.replaceChildren();bookmarks.slice(0,6).forEach(item=>{const b=document.createElement('button');b.className='quick-link';b.innerHTML=`<span class="app-square">${escape(item.name.slice(0,1).toUpperCase())}</span><span>${escape(item.name.slice(0,14))}</span>`;b.onclick=()=>navigate(item.url,tab);links.appendChild(b);});}
function renderTabs(){$('#tabs').replaceChildren();for(const tab of tabs){const wrap=document.createElement('div');wrap.className='tab'+(tab.id===activeId?' active':'');const select=document.createElement('button');select.className='tab-select';select.role='tab';select.setAttribute('aria-selected',String(tab.id===activeId));select.title=tab.title;select.innerHTML=(tab.loading?icon('reload'):`<span class="tab-number" aria-hidden="true">${String(tabs.indexOf(tab)+1).padStart(3,'0')}</span>`)+`<span>${escape(tab.title)}</span>`;select.setAttribute('aria-label',`Tab ${tabs.indexOf(tab)+1}: ${tab.title}`);select.onclick=()=>selectTab(tab.id);const close=document.createElement('button');close.className='tab-close';close.setAttribute('aria-label','Close '+tab.title);close.innerHTML=icon('close');close.onclick=()=>closeTab(tab.id);wrap.append(select,close);$('#tabs').appendChild(wrap);}}
function selectTab(id){activeId=id;for(const tab of tabs)tab.view.hidden=tab.id!==id;$('#browser-error').hidden=true;renderTabs();updateStatus();applyPageZoom(currentTab());}
function closeTab(id){const index=tabs.findIndex(t=>t.id===id);if(index<0)return;const tab=tabs[index];cleanup(tab);tab.view.remove();tabs.splice(index,1);if(!tabs.length)newTab();else if(activeId===id)selectTab(tabs[Math.max(0,index-1)].id);else renderTabs();}
function updateStatus(){const tab=currentTab();$('#address').value=tab?.url||'';$('#browser-engine').textContent=tab?.url?(tab.engine==='scramjet'?'Scramjet':'MOONLIGHT OS Basic'):engineName();$('#page-status').textContent=tab?.loading?'Opening page…':tab?.url?'In your window':'Ready to explore';$('[data-action="back"]').disabled=!tab?.url||(tab.engine==='basic'&&tab.position<=0);$('[data-action="forward"]').disabled=!tab?.url||(tab.engine==='basic'&&tab.position>=tab.entries.length-1);}
function resolveAddress(text){text=text.trim();if(!text)throw Error('Enter a website or a search.');if(text.length>8000)throw Error('That address is too long.');if(/^[a-z][a-z\d+.-]*:/i.test(text)&&!/^https?:/i.test(text))throw Error('Use an http or https website address.');let url;if(/^https?:\/\//i.test(text))url=new URL(text);else if(!/\s/.test(text)&&/^[^/]+\.[^/]+/.test(text))url=new URL('https://'+text);else{const base=prefs.search==='duckduckgo'?'https://duckduckgo.com/?q=':'https://www.google.com/search?q=';url=new URL(base+encodeURIComponent(text));}if(!['http:','https:'].includes(url.protocol)||url.username||url.password)throw Error('Use a website address without embedded login details.');return url.href;}
function pageLabel(url){try{return new URL(url).hostname.replace(/^www\./,'');}catch{return 'Webpage';}}
function record(tab){if(!tab.url)return;recent=[{url:tab.url,title:tab.title,time:Date.now()},...recent.filter(item=>item.url!==tab.url)].slice(0,40);save('history',recent);renderResume();}
function renderResume(){const last=recent[0];$('#resume-title').textContent=last?.title||'A fresh start';$('#resume-host').textContent=last?pageLabel(last.url):'Open a new window';}
function fail(tab,message){setLoading(tab,false);if(tab.id===activeId){$('#browser-error span').textContent=message;$('#browser-error').hidden=false;}else toast(tab.title+': '+message);}
function setLoading(tab,value){tab.loading=value;clearTimeout(tab.timer);tab.view.querySelector('.page-loading')?.remove();if(value){const line=document.createElement('div');line.className='page-loading';tab.view.appendChild(line);tab.timer=setTimeout(()=>{if(tab.loading)fail(tab,'The page is taking longer than expected. Your free Render server may be waking up. Wait a moment and press Reload.');},65000);}renderTabs();if(tab.id===activeId)updateStatus();}
async function startScramjet(){if(controllerPromise)return controllerPromise;controllerPromise=(async()=>{if(!navigator.serviceWorker)throw Error('Scramjet needs a browser that allows service workers over HTTPS.');if(!window.$scramjetLoadController||!window.BareMux)throw Error('Scramjet files did not load. Refresh the page and try again.');const {ScramjetController}=window.$scramjetLoadController();const controller=new ScramjetController({prefix:'/scramjet/',files:{wasm:'/scram/scramjet.wasm.wasm',all:'/scram/scramjet.all.js',sync:'/scram/scramjet.sync.js'},flags:{syncxhr:false}});await controller.init();const registration=await navigator.serviceWorker.register('/scramjet/sw.js',{scope:'/scramjet/'});if(!registration.active){const worker=registration.installing||registration.waiting;if(!worker)throw Error('Scramjet could not activate. Reload and try again.');await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{worker.removeEventListener('statechange',check);reject(Error('Scramjet setup timed out. Refresh and try again.'));},20000);function check(){if(worker.state==='activated'){clearTimeout(timer);worker.removeEventListener('statechange',check);resolve();}if(worker.state==='redundant'){clearTimeout(timer);worker.removeEventListener('statechange',check);reject(Error('Scramjet service worker failed.'));}}worker.addEventListener('statechange',check);check();});}const connection=new window.BareMux.BareMuxConnection('/baremux/worker.js');await connection.setTransport('/libcurl/index.mjs',[{websocket:(location.protocol==='https:'?'wss:':'ws:')+'//'+location.host+'/wisp/'}]);return controller;})().catch(error=>{controllerPromise=undefined;throw error;});return controllerPromise;}
async function navigate(value,tab=currentTab(),mode='new'){
 if(!tab)return;let url;try{url=resolveAddress(value);}catch(error){fail(tab,error.message);return;}showBrowser();$('#browser-error').hidden=true;const newEngine=prefs.engine;tab.request?.abort();const seq=++tab.seq;
 if(tab.engine!==newEngine||!tab.frame){tab.view.replaceChildren();tab.frame=null;tab.scram=null;tab.engine=newEngine;}
 tab.url=url;tab.title=pageLabel(url);setLoading(tab,true);record(tab);
 try{
  if(tab.engine==='scramjet'){
   const controller=await startScramjet();if(tab.seq!==seq)return;
   if(!tab.frame){const element=document.createElement('iframe');element.title='Scramjet webpage';element.referrerPolicy='no-referrer';element.allow='fullscreen';tab.frame=element;tab.scram=controller.createFrame(element);element.addEventListener('load',()=>{if(!element.getAttribute('src'))return;setLoading(tab,false);try{const title=element.contentDocument?.title;if(title&&!title.includes('Scramjet Error')){tab.title=title.slice(0,100);renderTabs();record(tab);}}catch{}});tab.scram.addEventListener('urlchange',event=>{const value=event.url?.toString();if(value&&/^https?:\/\//.test(value)){tab.url=value;tab.title=pageLabel(value);record(tab);renderTabs();if(tab.id===activeId)updateStatus();}});tab.view.appendChild(element);applyPageZoom(tab);}
   tab.scram.go(url);
  }else{
   tab.request=new AbortController();const response=await fetch('/api/basic?url='+encodeURIComponent(url),{signal:AbortSignal.any([tab.request.signal,AbortSignal.timeout(25000)])});const result=await response.json();if(tab.seq!==seq)return;if(!response.ok)throw Error(result.error||'This page could not load in Basic. Try Scramjet.');if(!tab.frame){tab.frame=document.createElement('iframe');tab.frame.title='Basic webpage';tab.frame.setAttribute('sandbox','allow-scripts');tab.frame.referrerPolicy='no-referrer';tab.frame.onload=()=>setLoading(tab,false);tab.view.appendChild(tab.frame);applyPageZoom(tab);}tab.frame.srcdoc=result.html;tab.url=result.url;tab.title=pageLabel(result.url);if(mode==='new'){tab.entries=[...tab.entries.slice(0,tab.position+1),result.url];tab.position=tab.entries.length-1;}record(tab);renderTabs();updateStatus();
  }
 }catch(error){if(tab.seq===seq&&error.name!=='AbortError')fail(tab,error.name==='TimeoutError'?'The request timed out. Try again or select Scramjet.':error.message||'Unable to open this page.');}
}
function browserMove(action){const tab=currentTab();if(!tab?.url)return;if(action==='reload'){if(tab.engine==='scramjet'&&tab.scram){setLoading(tab,true);tab.scram.reload();}else navigate(tab.url,tab,'reload');return;}if(tab.engine==='scramjet'){try{tab.scram?.[action]();}catch{toast('Navigation is not available yet.');}}else{const position=tab.position+(action==='back'?-1:1);if(position>=0&&position<tab.entries.length){tab.position=position;navigate(tab.entries[position],tab,'history');}}}
window.addEventListener('message',event=>{const tab=tabs.find(t=>t.engine==='basic'&&t.frame?.contentWindow===event.source);if(tab&&event.data?.type==='night-navigate'&&typeof event.data.url==='string')navigate(event.data.url,tab);});
function showPanel(name,section){panelName=name;$('#panel-window').classList.remove('wallpaper-panel');if(section)settingsTab=section;showWindow($('#panel-window'));$('#launcher').hidden=true;const titles={settings:'Settings',bookmarks:'Bookmarks',history:'Recent pages',notes:'Notes'};$('#panel-title').textContent=titles[name];$('#panel-icon').dataset.icon={settings:'settings',bookmarks:'bookmark',history:'history',notes:'note'}[name];const body=$('#panel-content');
 if(name==='settings')renderSettings();else if(name==='notes'){body.innerHTML='<h2>A thought worth keeping.</h2><p class="panel-intro">A quiet place for notes, ideas, and things to remember.</p><textarea class="notes-editor" id="notes-text" aria-label="Your notes" placeholder="Start anywhere…" maxlength="50000"></textarea><div class="notes-meta"><span id="notes-saved">Saved on this device</span><span id="notes-count"></span></div>';const field=$('#notes-text');field.value=read('notes','');$('#notes-count').textContent=field.value.length+' characters';field.oninput=()=>{$('#notes-saved').textContent=save('notes',field.value)?'Saved on this device':'Not saved';$('#notes-count').textContent=field.value.length+' characters';};}
 else renderList(name);paintIcons($('#panel-window'));
}
function renderSettings(){$('#panel-window').classList.toggle('wallpaper-panel',settingsTab==='appearance');const body=$('#panel-content');body.innerHTML='<h2>Make yourself at home.</h2><p class="panel-intro">Your colors, your atmosphere, your Moonlight.</p><div class="settings-nav" role="tablist" aria-label="Settings categories">'+['engines','appearance','storage'].map(name=>`<button role="tab" aria-selected="${name===settingsTab}" class="${name===settingsTab?'active':''}" data-settings-tab="${name}">${name==='engines'?'Proxy engines':name==='appearance'?'Appearance':'Your data'}</button>`).join('')+'</div><div id="settings-body"></div>';const area=$('#settings-body');
 if(settingsTab==='engines'){area.innerHTML=`<div class="section-label">BROWSING ENGINE</div>${[{id:'scramjet',name:'Scramjet',icon:'zap',sub:'Interactive websites',text:'Opens websites inside MOONLIGHT OS, using the relay on this same server. Supports JavaScript, forms, and many interactive pages.'},{id:'basic',name:'MOONLIGHT OS Basic',icon:'globe',sub:'Simple pages',text:'A lightweight reader for public webpages. Website scripts and forms are turned off. For games, video, or sign-ins, use Scramjet.'}].map(engine=>`<article class="engine-card ${prefs.engine===engine.id?'selected':''}"><div class="engine-head"><span class="app-square">${icon(engine.icon)}</span><div><h3>${engine.name}</h3><small>${engine.sub}</small></div><span class="badge">${prefs.engine===engine.id?'SELECTED':'AVAILABLE'}</span></div><p>${engine.text}</p><button class="primary" data-engine="${engine.id}">${prefs.engine===engine.id?'Currently selected':'Use '+engine.name}</button></article>`).join('')}<article class="engine-card"><div class="engine-head"><span class="app-square">${icon('globe')}</span><div><h3>Ultraviolet</h3><small>Not installed</small></div><span class="badge">SETUP REQUIRED</span></div><p>Scramjet is ready to use. Ultraviolet requires its own installation.</p></article><label class="setting-row"><span>Search engine<small>Used when you enter words instead of a URL.</small></span><select id="search-engine"><option value="google">Google</option><option value="duckduckgo">DuckDuckGo</option></select></label><p class="fine-print">Changing engines applies to new navigation. Existing pages stay open. Some websites reject proxies or need browser features that aren’t supported.</p>`;$('#search-engine').value=prefs.search;$('#search-engine').onchange=e=>{prefs.search=e.target.value;save('settings',prefs);};}
 if(settingsTab==='appearance'){
  const chosen=wallpaperTarget==='welcome'?prefs.welcomeWallpaper:prefs.wallpaper;
  area.innerHTML=`<div class="wallpaper-toolbar"><h3>WALLPAPER STUDIO</h3><label>Loop video <input id="wallpaper-loop" class="toggle" type="checkbox" ${prefs.loopWallpaper?'checked':''}></label></div><div class="wallpaper-targets" role="group" aria-label="Wallpaper destination">${[['both','Both'],['desktop','Desktop'],['welcome','Welcome screen']].map(([value,label])=>`<button class="${wallpaperTarget===value?'active':''}" data-wallpaper-target="${value}" aria-pressed="${wallpaperTarget===value}">${label}</button>`).join('')}</div><div class="wallpaper-choices">${['moonlight','starlight','mischevious','galaxy','midnight','aurora','ember','glacier','void'].map(name=>`<button class="wallpaper-choice ${chosen===name?'active':''}" data-wallpaper="${name}" data-value="${name}" aria-label="${name} wallpaper" aria-pressed="${chosen===name}"><span>${name[0].toUpperCase()+name.slice(1)}</span></button>`).join('')}<button class="wallpaper-choice custom-wallpaper ${chosen==='custom'?'active':''}" data-wallpaper="custom" data-value="custom" aria-label="Use uploaded wallpaper"><i data-icon="palette"></i><span>Your wallpaper</span></button></div><label class="wallpaper-upload secondary">${icon('plus')} Upload image or video<input id="wallpaper-file" type="file" accept="image/png,image/jpeg,image/webp,image/gif,video/mp4,video/webm" hidden></label><p class="fine-print">Upload a PNG, JPG, WebP, GIF, MP4, or WebM up to 20 MB. Saved on this device. Videos play muted. Reduced motion shows a still frame.</p><div class="section-label">ACCENT COLOR</div><div class="color-choices">${['violet','ice','rose'].map(name=>`<button class="color-choice ${prefs.accent===name?'active':''}" data-accent="${name}" data-value="${name}" aria-label="${name} accent" aria-pressed="${prefs.accent===name}"></button>`).join('')}</div><label class="setting-row"><span>24-hour clock<small>Use 18:00 instead of 6:00 PM.</small></span><input id="clock24" class="toggle" type="checkbox" ${prefs.clock24?'checked':''}></label><label class="setting-row"><span>Interface motion<small>Smooth screen transitions, windows, and video wallpapers.</small></span><input id="motion" class="toggle" type="checkbox" ${prefs.motion?'checked':''}></label><label class="setting-row"><span>Live atmosphere<small>Moving ocean, soft light, and drifting stars. Turn off for a still background.</small></span><input id="live-wallpaper" class="toggle" type="checkbox" ${prefs.liveWallpaper?'checked':''}></label><button class="secondary" data-action="welcome">Replay welcome animation</button>`;
  $('#clock24').onchange=e=>{prefs.clock24=e.target.checked;save('settings',prefs);applyPrefs();};$('#motion').onchange=e=>{prefs.motion=e.target.checked;save('settings',prefs);applyPrefs();};$('#wallpaper-loop').onchange=e=>{prefs.loopWallpaper=e.target.checked;save('settings',prefs);applyWallpapers();};$('#wallpaper-file').onchange=uploadWallpaper;$('#live-wallpaper').onchange=e=>{prefs.liveWallpaper=e.target.checked;save('settings',prefs);applyPrefs();};
 }
 if(settingsTab==='storage'){area.innerHTML=`<div class="storage-status">${icon('desktop')} Settings, bookmarks, notes, and recent pages stay in this browser.</div><p class="fine-print">These don’t sync between devices or transfer automatically from your old ChatGPT Site. Clearing browser data removes them. Export a copy before switching devices.</p><button class="secondary" data-action="export">${icon('download')} Export your data</button><div class="section-label">RECENT PAGES</div><p class="panel-intro">MOONLIGHT OS remembers up to 40 recent pages on this device.</p><button class="secondary danger" data-action="clear-history">Clear recent pages</button><div class="section-label">ABOUT MOONLIGHT OS</div><p class="fine-print">Independent desktop browser · Desktop 02<br>Powered by Scramjet, Bare Mux, Libcurl, and Wisp.<br><a href="/credits.html" target="_blank" rel="noopener noreferrer">Third-party credits and licenses</a> · <a href="/night-window-source.zip" download>Source code</a></p>`;}
 paintIcons(body);
}
function renderList(name){const isBookmarks=name==='bookmarks',list=isBookmarks?bookmarks:recent;$('#panel-content').innerHTML=`<h2>${isBookmarks?'Keep the good stuff.':'Back to something good.'}</h2><p class="panel-intro">${isBookmarks?'Your shortcuts appear on every new tab.':'Your 40 most recent pages, saved on this device.'}</p><div id="saved-list"></div>${isBookmarks?'<form id="bookmark-form" class="inline-form"><div class="section-label">ADD A SHORTCUT</div><input name="name" placeholder="Name" aria-label="Bookmark name" maxlength="60" required><input name="url" placeholder="https://example.com" aria-label="Bookmark URL" required><button class="primary" type="submit">Add bookmark</button></form>':''}`;const container=$('#saved-list');if(!list.length)container.innerHTML='<div class="empty-state">Nothing here yet.<br>Open a page to get started.</div>';list.forEach((item,index)=>{const row=document.createElement('div');row.className='list-row';const open=document.createElement('button');open.innerHTML=`<span class="app-square">${icon(isBookmarks?'bookmark':'history')}</span><span class="row-label"><b>${escape(item.name||item.title||pageLabel(item.url))}</b><small>${escape(pageLabel(item.url))}${item.time?' · '+escape(new Date(item.time).toLocaleDateString()):''}</small></span>`;open.onclick=()=>{showBrowser();navigate(item.url);$('#panel-window').hidden=true;};const remove=document.createElement('button');remove.className='icon-button';remove.innerHTML=icon('trash');remove.setAttribute('aria-label','Remove '+(item.name||item.title));remove.onclick=()=>{list.splice(index,1);save(isBookmarks?'bookmarks':'history',list);renderList(name);tabs.forEach(renderQuickLinks);renderResume();};row.append(open,remove);container.appendChild(row);});if(isBookmarks)$('#bookmark-form').onsubmit=e=>{e.preventDefault();try{const form=e.target,name=form.elements.name.value.trim(),url=resolveAddress(form.elements.url.value);if(bookmarks.length>=60)throw Error('You have 60 bookmarks. Remove one before adding another.');bookmarks.push({name,url});save('bookmarks',bookmarks);renderList('bookmarks');tabs.forEach(renderQuickLinks);toast('Bookmark saved.');}catch(error){toast(error.message);}};}
const apps=[{name:'Browser',icon:'globe',action:'browser'},{name:'Bookmarks',icon:'bookmark',action:'bookmarks'},{name:'Recent pages',icon:'history',action:'history'},{name:'Notes',icon:'note',action:'notes'},{name:'Settings',icon:'settings',action:'settings'},{name:'Appearance',icon:'palette',action:'appearance'},{name:'Desktop',icon:'desktop',action:'desktop'},{name:'Welcome',icon:'expand',action:'welcome'}];
function renderLauncher(query=''){const filtered=apps.filter(app=>app.name.toLowerCase().includes(query.toLowerCase()));$('#launcher-apps').innerHTML=filtered.length?filtered.map(app=>`<button class="launcher-app" data-action="${app.action}"><span class="app-square">${icon(app.icon)}</span><span>${app.name}</span></button>`).join(''):'<p class="fine-print">No matching apps.</p>';}
const actions={motion:()=>{prefs.liveWallpaper=!prefs.liveWallpaper;save('settings',prefs);applyPrefs();if(!$('#panel-window').hidden&&panelName==='settings'&&settingsTab==='appearance')renderSettings();},enter:enterDesktop,welcome:showWelcome,browser:showBrowser,desktop:showDesktop,'minimize-browser':hideBrowser,'close-browser':hideBrowser,'close-panel':()=>{hideWindow($('#panel-window'));(document.body.classList.contains('browser-app-open')?$('#browser-window [data-action="settings"]'):$('.dock [data-action="settings"]')).focus({preventScroll:true});},maximize:maximizeBrowser,'zoom-in':()=>zoomPage(.1),'zoom-out':()=>zoomPage(-.1),'zoom-reset':()=>zoomPage(0),'new-tab':()=>{newTab();showBrowser();$('#address').focus();},home:()=>{const tab=currentTab();if(tab){renderHome(tab);updateStatus();}},back:()=>browserMove('back'),forward:()=>browserMove('forward'),reload:()=>browserMove('reload'),'dismiss-error':()=>$('#browser-error').hidden=true,settings:()=>showPanel('settings','engines'),appearance:()=>showPanel('settings','appearance'),notes:()=>showPanel('notes'),bookmarks:()=>showPanel('bookmarks'),history:()=>showPanel('history'),resume:()=>{showBrowser();if(recent[0])navigate(recent[0].url);},launcher:()=>{$('#launcher').hidden=!$('#launcher').hidden;if(!$('#launcher').hidden){$('#launcher-search').value='';renderLauncher();$('#launcher-search').focus();}},bookmark:()=>{const tab=currentTab();if(!tab?.url){showPanel('bookmarks');return;}if(bookmarks.some(item=>item.url===tab.url)){toast('This page is already bookmarked.');return;}if(bookmarks.length>=60){toast('Your bookmark list is full.');return;}bookmarks.push({name:tab.title.slice(0,60),url:tab.url});save('bookmarks',bookmarks);tabs.forEach(renderQuickLinks);toast('Added to your bookmarks.');},fullscreen:async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('Fullscreen is not available in this browser.');}},export:()=>{const blob=new Blob([JSON.stringify({version:1,settings:prefs,bookmarks,history:recent,notes:read('notes','')},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='moonlight-os-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);},'clear-history':()=>{if(confirm('Clear your recent pages on this device?')){recent=[];save('history',recent);renderResume();toast('Recent pages cleared.');}}};
document.addEventListener('click',event=>{const button=event.target.closest('button');if(!button||button.disabled)return;if(button.dataset.action)actions[button.dataset.action]?.();if(button.dataset.settingsTab){settingsTab=button.dataset.settingsTab;renderSettings();}if(button.dataset.engine){prefs.engine=button.dataset.engine;save('settings',prefs);applyPrefs();for(const tab of tabs)if(!tab.url)renderHome(tab);renderSettings();toast(engineName()+' selected.');}if(button.dataset.wallpaperTarget){wallpaperTarget=button.dataset.wallpaperTarget;renderSettings();}if(button.dataset.wallpaper){selectWallpaper(button.dataset.wallpaper);}if(button.dataset.accent){prefs.accent=button.dataset.accent;save('settings',prefs);applyPrefs();renderSettings();}});
$('#address-form').onsubmit=event=>{event.preventDefault();navigate($('#address').value);};$('#address').onfocus=event=>event.target.select();$('#launcher-search').oninput=event=>renderLauncher(event.target.value);
document.addEventListener('keydown',event=>{
 if(!$('#welcome-screen').hidden){
  if(event.key==='Enter'){event.preventDefault();enterDesktop();}
  if(event.key==='Tab'){event.preventDefault();$('#enter-desktop').focus();}
  return;
 }
 if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){
  event.preventDefault();showBrowser();$('#address').focus();$('#address').select();
 }
 if(event.key==='Escape'){
  $('#launcher').hidden=true;hideWindow($('#panel-window'));(document.body.classList.contains('browser-app-open')?$('.back-to-menu'):$('.desktop-browse')).focus({preventScroll:true});
 }
});
document.addEventListener('pointerdown',event=>{if(!event.target.closest('#launcher,.launcher-toggle'))$('#launcher').hidden=true;const windowEl=event.target.closest('.window');if(windowEl)focusWindow(windowEl);const title=event.target.closest('[data-drag]');if(!title||event.target.closest('button')||innerWidth<621||windowEl.classList.contains('maximized'))return;const rect=windowEl.getBoundingClientRect(),x=event.clientX,y=event.clientY;title.setPointerCapture(event.pointerId);function move(e){const left=Math.max(0,Math.min(innerWidth-100,rect.left+e.clientX-x));const top=Math.max(60,Math.min(innerHeight-150,rect.top+e.clientY-y));windowEl.style.left=left+'px';windowEl.style.top=top+'px';}function end(){title.removeEventListener('pointermove',move);title.removeEventListener('pointerup',end);title.removeEventListener('pointercancel',end);}title.addEventListener('pointermove',move);title.addEventListener('pointerup',end);title.addEventListener('pointercancel',end);});
window.addEventListener('resize',()=>{for(const el of document.querySelectorAll('.window')){if(el.hidden)continue;const rect=el.getBoundingClientRect();if(rect.left>innerWidth-100)el.style.left=Math.max(7,innerWidth-el.offsetWidth-15)+'px';if(rect.top>innerHeight-150)el.style.top='80px';}});
paintIcons();applyPrefs();renderResume();renderLauncher();setInterval(updateClock,1000);
let alreadyEntered=false;try{alreadyEntered=!!sessionStorage.getItem('nw:entered:door200');}catch{}
if(alreadyEntered){$('#welcome-screen').hidden=true;setDesktopInert(false);document.body.classList.remove('booting');document.body.classList.add('desktop-reveal');revealTimer=setTimeout(()=>document.body.classList.remove('desktop-reveal'),1550);applyWallpapers();}else showWelcome();
loadWallpaper();

// Local wallpaper storage. Large media stays out of localStorage.
function wallpaperDB(){return new Promise((resolve,reject)=>{const request=indexedDB.open('night-window-wallpapers',1);request.onupgradeneeded=()=>request.result.createObjectStore('media');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
async function loadWallpaper(){try{const db=await wallpaperDB();const item=await new Promise((resolve,reject)=>{const request=db.transaction('media').objectStore('media').get('custom');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});db.close();if(item){customWallpaperUrl=URL.createObjectURL(item);customWallpaperType=item.type;applyWallpapers();}}catch{/* Browsing works even when IndexedDB is unavailable. */}}
async function uploadWallpaper(event){const file=event.target.files?.[0];if(!file)return;if(!['image/png','image/jpeg','image/webp','image/gif','video/mp4','video/webm'].includes(file.type)){toast('Choose a PNG, JPG, WebP, GIF, MP4, or WebM file.');return;}if(file.size>20*1024*1024){toast('Choose a wallpaper smaller than 20 MB.');return;}try{const db=await wallpaperDB();await new Promise((resolve,reject)=>{const tx=db.transaction('media','readwrite');tx.objectStore('media').put(file,'custom');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});db.close();if(customWallpaperUrl)URL.revokeObjectURL(customWallpaperUrl);customWallpaperUrl=URL.createObjectURL(file);customWallpaperType=file.type;selectWallpaper('custom');toast('Wallpaper saved on this device.');}catch{toast('Could not save the wallpaper. Try a smaller file or allow local storage.');}}
function selectWallpaper(name){if(name==='custom'&&!customWallpaperUrl){toast('Upload an image or video first.');$('#wallpaper-file')?.click();return;}if(wallpaperTarget==='both'||wallpaperTarget==='desktop')prefs.wallpaper=name;if(wallpaperTarget==='both'||wallpaperTarget==='welcome')prefs.welcomeWallpaper=name;save('settings',prefs);applyPrefs();renderSettings();}
function applyWallpapers(){
 // These variables are initialized below startup; initial rendering uses the built-in theme.
 const customReady=typeof customWallpaperUrl==='string';
 for(const [surface,video,name] of [[$('.wallpaper'),$('#desktop-video'),prefs.wallpaper],[$('#welcome-wallpaper'),$('#welcome-video'),prefs.welcomeWallpaper]]){
  if(!surface||!video)continue;surface.dataset.theme=name||'galaxy';video.loop=prefs.loopWallpaper;
  const custom=name==='custom'&&customReady,isVideo=custom&&customWallpaperType.startsWith('video/');
  surface.style.backgroundImage=custom&&!isVideo?'linear-gradient(0deg,#05081333,#05081322),url("'+customWallpaperUrl+'")':'';
  if(isVideo){if(video.getAttribute('src')!==customWallpaperUrl)video.src=customWallpaperUrl;video.hidden=false;const reduce=!prefs.motion||window.matchMedia('(prefers-reduced-motion: reduce)').matches;const visible=video.id==='welcome-video'?!$('#welcome-screen').hidden:$('#welcome-screen').hidden;if(reduce||!visible||document.hidden){video.pause();}else video.play().catch(()=>{});}else{video.pause();video.hidden=true;video.removeAttribute('src');}
 }
 document.dispatchEvent(new Event('moonlight:scene'));
}
function setDesktopInert(value){
 for(const node of [$('#desktop'),$('.system-bar'),$('.dock'),$('#browser-window'),$('#panel-window'),$('#launcher')])node.inert=value;
}
function showWelcome(){
 clearTimeout(enterTimer);clearTimeout(revealTimer);entryInProgress=false;
 const el=$('#welcome-screen');
 el.classList.remove('is-leaving');el.hidden=false;
 document.body.classList.remove('entering','desktop-reveal');
 document.body.classList.add('booting');
 $('#enter-desktop').disabled=false;
 setDesktopInert(true);$('#enter-desktop').focus({preventScroll:true});
 applyWallpapers();
}
function enterDesktop(){
 const el=$('#welcome-screen');
 if(el.hidden||entryInProgress)return;
 entryInProgress=true;$('#enter-desktop').disabled=true;playDoorSound();
 const finish=()=>{
  el.hidden=true;el.classList.remove('is-leaving');setDesktopInert(false);
  document.body.classList.remove('booting');
  try{sessionStorage.setItem('nw:entered:door200','1');}catch{}
  applyWallpapers();$('.desktop-browse').focus({preventScroll:true});
  entryInProgress=false;$('#enter-desktop').disabled=false;
  if(motionAllowed())revealTimer=setTimeout(()=>document.body.classList.remove('entering'),1600);
  else document.body.classList.remove('entering');
 };
 if(!motionAllowed()){finish();return;}
 document.body.classList.add('entering');el.classList.add('is-leaving');
 document.dispatchEvent(new Event('moonlight:scene'));
 enterTimer=setTimeout(finish,3600);
}
window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',()=>{
 applyWallpapers();updateMotionLabel();
 if(entryInProgress&&!motionAllowed()){clearTimeout(enterTimer);entryInProgress=false;enterDesktop();}
});
document.addEventListener('visibilitychange',()=>{
 document.body.classList.toggle('page-paused',document.hidden);applyWallpapers();
});
